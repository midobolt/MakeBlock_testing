# KauLab
This is a library for the robot lab at Karlstad University. It requires both MeAuriga and the FreeRTOS library to work. 
